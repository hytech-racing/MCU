INTERPROCEDURAL_OPTIMIZATION_<CONFIG>
-------------------------------------

This directory property does not exist anymore.

See the target property :prop_tgt:`INTERPROCEDURAL_OPTIMIZATION_<CONFIG>` instead.
