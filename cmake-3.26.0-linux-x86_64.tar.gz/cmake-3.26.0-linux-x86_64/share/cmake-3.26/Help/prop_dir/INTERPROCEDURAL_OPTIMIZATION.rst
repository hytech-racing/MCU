INTERPROCEDURAL_OPTIMIZATION
----------------------------

This directory property does not exist anymore.

See the target property :prop_tgt:`INTERPROCEDURAL_OPTIMIZATION` instead.
